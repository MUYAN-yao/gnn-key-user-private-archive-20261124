﻿TOCS 2026 — 署名会议稿 LaTeX 源码
主文件 main.tex。使用 TeX Live 或 Overleaf，选择 pdfLaTeX，连续编译两次。参考文献由 references.tex 直接排版，不需要 BibTeX。需要 TeX Live 的 spie 文档类和 newtx 字体包。
main.pdf 是 LaTeX 编译稿；Original_signed_layout.pdf 是作为转换依据的原 8 页署名 Word 导出稿。两者的分页及浮动图表位置可不同。
